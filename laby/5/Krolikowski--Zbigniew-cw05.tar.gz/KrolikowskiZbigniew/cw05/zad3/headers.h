#define _GNU_SOURCE 
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
