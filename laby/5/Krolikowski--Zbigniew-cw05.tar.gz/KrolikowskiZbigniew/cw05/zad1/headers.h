#define _GNU_SOURCE 
#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/times.h>
#include <sys/time.h>
#include <sys/resource.h> 
#include <sched.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>

