#define std
#include <stdio.h>
#include <stdlib.h>

#include <time.h>
#include <sys/times.h>

#include <string.h>

int generate(char* filePath, int size, int count);
