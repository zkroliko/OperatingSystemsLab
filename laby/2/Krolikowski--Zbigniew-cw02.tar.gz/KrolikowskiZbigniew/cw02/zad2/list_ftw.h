#ifndef COMMON 
	#define COMMON
	#include "common.h"
#endif

#include <ftw.h>

int get_statistics(const char* dirPath, const struct stat* st, int flag);


