#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <limits.h>
#include <time.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

int count(char* filePath, short flag);

